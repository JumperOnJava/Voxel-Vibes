# Voxel vibes 

Simple shader with focus on keeping vanilla look

Based on [XorDevs Default Shaderpack](https://github.com/XorDev/XorDevs-Default-Shaderpack)